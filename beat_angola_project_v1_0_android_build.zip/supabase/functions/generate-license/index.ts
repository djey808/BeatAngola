import { createClient } from "npm:@supabase/supabase-js@2";

const url = Deno.env.get("SUPABASE_URL")!;
const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method Not Allowed", {status:405});
  const auth = req.headers.get("Authorization");
  if (!auth) return Response.json({error:"missing_auth"}, {status:401});

  const admin = createClient(url, key);
  const token = auth.replace("Bearer ", "");
  const {data: ud, error: ue} = await admin.auth.getUser(token);
  if (ue || !ud.user) return Response.json({error:"invalid_auth"}, {status:401});

  const {acquired_license_id} = await req.json();
  const {data, error} = await admin
    .from("acquired_licenses")
    .select("id,user_id,order_id,beat_id,license_type,price,currency,created_at")
    .eq("id", acquired_license_id)
    .eq("user_id", ud.user.id)
    .maybeSingle();

  if (error || !data) return Response.json({error:"license_not_found"}, {status:404});

  // v0.7 devolve os dados normalizados.
  // A geração de PDF/assinatura criptográfica será adicionada na camada documental.
  return Response.json({
    license: data,
    document_status: "data_ready",
  });
});
