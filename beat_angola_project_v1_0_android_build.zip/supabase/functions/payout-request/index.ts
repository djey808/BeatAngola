// Endpoint backend para solicitar payout.
// O cliente não chama este endpoint com credenciais privilegiadas.
// Validar JWT do utilizador e derivar a wallet a partir do auth.uid().
//
// Antes de produção:
// - KYC/identidade quando exigido
// - verificar saldo disponível
// - verificar método e país
// - aplicar limites e taxas
// - reservar o valor
// - enviar ao payout provider
// - processar webhook de payout
//
// Nunca enviar service-role key para o Flutter.

Deno.serve(async (req) => {
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  return Response.json({
    status: "not_implemented",
    message: "Payout provider adapter será configurado na próxima etapa.",
  }, { status: 501 });
});
