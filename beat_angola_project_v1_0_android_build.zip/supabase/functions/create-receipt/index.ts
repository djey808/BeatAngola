import { createClient } from "npm:@supabase/supabase-js@2";

const url = Deno.env.get("SUPABASE_URL")!;
const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const admin = createClient(url, key);

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method Not Allowed", {status:405});

  const auth = req.headers.get("Authorization");
  if (!auth) return Response.json({error:"missing_auth"}, {status:401});

  const token = auth.replace("Bearer ", "");
  const {data: userData, error: userError} = await admin.auth.getUser(token);
  if (userError || !userData.user) return Response.json({error:"invalid_auth"}, {status:401});

  const {order_id} = await req.json();
  if (!order_id) return Response.json({error:"missing_order"}, {status:400});

  const {data, error} = await admin
    .from("receipts")
    .select("id,order_id,receipt_number,currency,amount,issued_at,storage_path")
    .eq("order_id", order_id)
    .maybeSingle();

  if (error || !data) return Response.json({error:"receipt_not_found"}, {status:404});

  const {data: order} = await admin
    .from("orders")
    .select("id,user_id,status")
    .eq("id", order_id)
    .eq("user_id", userData.user.id)
    .maybeSingle();

  if (!order || order.status != "paid") {
    return Response.json({error:"order_not_authorized"}, {status:403});
  }

  return Response.json({receipt: data});
});
