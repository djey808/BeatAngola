import { createClient } from "npm:@supabase/supabase-js@2";

const url = Deno.env.get("SUPABASE_URL")!;
const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const admin = createClient(url, key);

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method Not Allowed", {status:405});

  const auth = req.headers.get("Authorization");
  if (!auth) return Response.json({error:"missing_auth"}, {status:401});

  const token = auth.replace("Bearer ", "");
  const {data: userData, error: userError} = await admin.auth.getUser(token);
  if (userError || !userData.user) return Response.json({error:"invalid_auth"}, {status:401});

  const {acquired_license_id} = await req.json();
  if (!acquired_license_id) return Response.json({error:"missing_license"}, {status:400});

  const {data, error} = await admin
    .from("acquired_licenses")
    .select(`
      id,user_id,order_id,beat_id,license_type,price,currency,created_at,
      license_documents(document_number,version,document_hash,created_at)
    `)
    .eq("id", acquired_license_id)
    .eq("user_id", userData.user.id)
    .maybeSingle();

  if (error || !data) return Response.json({error:"license_not_found"}, {status:404});

  const {data: beat} = await admin
    .from("beats")
    .select("id,title,producer_id")
    .eq("id", data.beat_id)
    .maybeSingle();

  return Response.json({
    license: data,
    beat: beat,
    generated_for: userData.user.id,
  });
});
