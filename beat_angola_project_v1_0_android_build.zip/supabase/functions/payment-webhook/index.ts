// Exemplo de Supabase Edge Function.
// Em produção, validar a assinatura do webhook conforme o provedor escolhido
// antes de chamar complete_paid_order.
//
// Não coloque chaves secretas no Flutter.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  const body = await req.json();

  // TODO v0.6:
  // 1. Validar assinatura do provedor.
  // 2. Extrair event_id, order_id, payment_id e estado.
  // 3. Ignorar eventos já processados.
  // 4. Apenas para um estado confirmado, chamar a função SQL.
  //
  // Exemplo de shape interno:
  // {
  //   provider: "provider_name",
  //   event_id: "...",
  //   order_id: "...",
  //   payment_id: "...",
  //   status: "paid"
  // }

  const provider = String(body.provider ?? "");
  const eventId = String(body.event_id ?? "");
  const orderId = String(body.order_id ?? "");
  const paymentId = String(body.payment_id ?? "");
  const status = String(body.status ?? "");

  if (!provider || !eventId || !orderId || !paymentId) {
    return new Response("Invalid event", { status: 400 });
  }

  if (status !== "paid") {
    return Response.json({ received: true, processed: false });
  }

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    { auth: { persistSession: false } }
  );

  const { error: eventError } = await supabase
    .from("payment_events")
    .insert({
      provider,
      external_event_id: eventId,
      event_type: "payment.confirmed",
      order_id: orderId,
      payload: body,
      processed_at: new Date().toISOString(),
    });

  if (eventError && !String(eventError.message).includes("duplicate")) {
    return new Response("Could not record event", { status: 500 });
  }

  const { error } = await supabase.rpc("complete_paid_order", {
    p_order_id: orderId,
    p_provider: provider,
    p_external_payment_id: paymentId,
  });

  if (error) {
    return new Response("Could not complete order", { status: 500 });
  }

  return Response.json({ received: true, processed: true });
});
