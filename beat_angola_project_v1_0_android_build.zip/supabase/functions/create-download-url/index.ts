import { createClient } from "npm:@supabase/supabase-js@2";

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

Deno.serve(async (req) => {
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  const authHeader = req.headers.get("Authorization");
  if (!authHeader) return Response.json({error:"missing_auth"}, {status:401});

  const admin = createClient(supabaseUrl, serviceKey);
  const token = authHeader.replace("Bearer ", "");
  const { data: userData, error: userError } = await admin.auth.getUser(token);
  if (userError || !userData.user) {
    return Response.json({error:"invalid_auth"}, {status:401});
  }

  const body = await req.json();
  const acquiredLicenseId = body.acquired_license_id;
  const beatFileId = body.beat_file_id;
  if (!acquiredLicenseId || !beatFileId) {
    return Response.json({error:"missing_parameters"}, {status:400});
  }

  const { data: license, error: licenseError } = await admin
    .from("acquired_licenses")
    .select("id,user_id,order_id,beat_id,license_type")
    .eq("id", acquiredLicenseId)
    .eq("user_id", userData.user.id)
    .maybeSingle();

  if (licenseError || !license) {
    return Response.json({error:"license_not_found"}, {status:404});
  }

  const { data: file, error: fileError } = await admin
    .from("beat_files")
    .select("id,beat_id,storage_path,file_type")
    .eq("id", beatFileId)
    .eq("beat_id", license.beat_id)
    .maybeSingle();

  if (fileError || !file || !file.storage_path) {
    return Response.json({error:"file_not_found"}, {status:404});
  }

  // URL curta: reduz a janela em que uma URL copiada continua utilizável.
  const expiresIn = 300;
  const { data: signed, error: signedError } = await admin
    .storage
    .from("beat-originals")
    .createSignedUrl(file.storage_path, expiresIn, { download: true });

  if (signedError || !signed?.signedUrl) {
    return Response.json({error:"could_not_sign"}, {status:500});
  }

  await admin.from("download_events").insert({
    user_id: userData.user.id,
    acquired_license_id: license.id,
    beat_file_id: file.id,
    user_agent: req.headers.get("user-agent"),
  });

  return Response.json({
    url: signed.signedUrl,
    expires_in: expiresIn,
    file_type: file.file_type,
  });
});
