-- Beat Angola v0.6
-- Catálogo de métodos por país/moeda.
-- Os provedores reais serão configurados pelo backend/admin.

create table if not exists public.payment_methods (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  provider text not null,
  method_type text not null,
  currency text not null,
  countries text[] not null default '{}',
  enabled boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.payout_methods (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  provider text not null,
  method_type text not null,
  currency text not null,
  countries text[] not null default '{}',
  enabled boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.payment_methods enable row level security;
alter table public.payout_methods enable row level security;

drop policy if exists "public read enabled payment methods" on public.payment_methods;
create policy "public read enabled payment methods"
on public.payment_methods for select
using (enabled = true);

drop policy if exists "public read enabled payout methods" on public.payout_methods;
create policy "public read enabled payout methods"
on public.payout_methods for select
using (enabled = true);

alter table public.payouts
  add column if not exists destination jsonb not null default '{}'::jsonb;

-- Nunca permitir que um cliente escolha diretamente o producer_id.
-- O backend deve derivá-lo da carteira e do utilizador autenticado.
revoke insert, update, delete on public.payouts from anon, authenticated;

-- Exemplos desativados até a administração configurar os provedores.
insert into public.payment_methods
(name, provider, method_type, currency, countries, enabled)
values
('Cartão internacional', 'provider_adapter', 'card', 'USD', ARRAY['AO','BR','PT','US','GB'], false),
('Cartão internacional', 'provider_adapter', 'card', 'EUR', ARRAY['AO','BR','PT','US','GB'], false),
('Cartão internacional', 'provider_adapter', 'card', 'AOA', ARRAY['AO'], false);

insert into public.payout_methods
(name, provider, method_type, currency, countries, enabled)
values
('Transferência bancária', 'provider_adapter', 'bank_transfer', 'AOA', ARRAY['AO'], false),
('Transferência bancária', 'provider_adapter', 'bank_transfer', 'USD', ARRAY['AO','BR','PT','US','GB'], false);
