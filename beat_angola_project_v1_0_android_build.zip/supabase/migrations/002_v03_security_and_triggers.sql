-- Beat Angola v0.3
-- Trigger de perfil + políticas básicas para o marketplace.
-- Revise estas políticas antes de produção.

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  requested_role text := coalesce(new.raw_user_meta_data->>'role', 'artist');
  safe_role public.account_role := 'artist';
begin
  if requested_role in ('artist', 'producer', 'both') then
    safe_role := requested_role::public.account_role;
  end if;

  insert into public.profiles (
    id, display_name, country_code, preferred_language, preferred_currency, role
  )
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data->>'display_name', ''), split_part(coalesce(new.email, 'user'), '@', 1)),
    upper(coalesce(nullif(new.raw_user_meta_data->>'country_code', ''), 'AO')),
    'pt',
    case when upper(coalesce(new.raw_user_meta_data->>'country_code', 'AO')) = 'AO' then 'AOA' else 'USD' end,
    safe_role
  )
  on conflict (id) do nothing;

  if safe_role in ('producer', 'both') then
    insert into public.producer_profiles (user_id, stage_name)
    values (
      new.id,
      coalesce(nullif(new.raw_user_meta_data->>'display_name', ''), split_part(coalesce(new.email, 'producer'), '@', 1))
    )
    on conflict (user_id) do nothing;
  end if;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

alter table public.producer_profiles enable row level security;
alter table public.licenses enable row level security;

drop policy if exists "public read producer profiles" on public.producer_profiles;
create policy "public read producer profiles"
on public.producer_profiles for select
using (true);

drop policy if exists "producer manages own profile" on public.producer_profiles;
create policy "producer manages own profile"
on public.producer_profiles for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "public read active licenses" on public.licenses;
create policy "public read active licenses"
on public.licenses for select
using (active = true);

drop policy if exists "producer manages own licenses" on public.licenses;
create policy "producer manages own licenses"
on public.licenses for all
using (
  exists (
    select 1
    from public.beats b
    join public.producer_profiles pp on pp.id = b.producer_id
    where b.id = licenses.beat_id
      and pp.user_id = auth.uid()
  )
)
with check (
  exists (
    select 1
    from public.beats b
    join public.producer_profiles pp on pp.id = b.producer_id
    where b.id = licenses.beat_id
      and pp.user_id = auth.uid()
  )
);

drop policy if exists "public read producer profiles via published beats" on public.producer_profiles;
create policy "public read producer profiles via published beats"
on public.producer_profiles for select
using (true);
