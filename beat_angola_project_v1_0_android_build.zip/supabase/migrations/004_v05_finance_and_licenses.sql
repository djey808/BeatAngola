-- Beat Angola v0.5
-- Pós-pagamento, licenças adquiridas e ledger.

create table if not exists public.acquired_licenses (
  id uuid primary key default gen_random_uuid(),
  order_item_id uuid not null unique references public.order_items(id) on delete restrict,
  buyer_id uuid not null references public.profiles(id) on delete restrict,
  beat_id uuid not null references public.beats(id) on delete restrict,
  license_id uuid not null references public.licenses(id) on delete restrict,
  license_type public.license_type not null,
  producer_id uuid not null references public.producer_profiles(id) on delete restrict,
  license_document_path text,
  acquired_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create index if not exists idx_acquired_licenses_buyer
on public.acquired_licenses(buyer_id);

create index if not exists idx_acquired_licenses_beat
on public.acquired_licenses(beat_id);

alter table public.acquired_licenses enable row level security;

drop policy if exists "buyers read acquired licenses" on public.acquired_licenses;
create policy "buyers read acquired licenses"
on public.acquired_licenses for select
using (auth.uid() = buyer_id);

create table if not exists public.payment_events (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  external_event_id text not null,
  event_type text not null,
  order_id uuid references public.orders(id) on delete set null,
  payload jsonb not null default '{}'::jsonb,
  processed_at timestamptz,
  created_at timestamptz not null default now(),
  unique(provider, external_event_id)
);

alter table public.payment_events enable row level security;

-- Nenhuma política pública: eventos de pagamento são backend-only.

create or replace function public.complete_paid_order(
  p_order_id uuid,
  p_provider text,
  p_external_payment_id text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  o public.orders;
  item public.order_items;
  l public.licenses;
  b public.beats;
  producer_wallet public.wallets;
  producer_share numeric;
begin
  select * into o
  from public.orders
  where id = p_order_id
  for update;

  if not found then
    raise exception 'Pedido não encontrado';
  end if;

  if o.status = 'paid' then
    return;
  end if;

  if o.status in ('refunded', 'disputed') then
    raise exception 'Pedido não pode ser pago neste estado';
  end if;

  update public.orders
  set status = 'paid',
      payment_provider = p_provider,
      external_payment_id = p_external_payment_id,
      paid_at = now()
  where id = p_order_id;

  for item in
    select * from public.order_items
    where order_id = p_order_id
    for update
  loop
    select * into l from public.licenses where id = item.license_id for update;
    select * into b from public.beats where id = item.beat_id for update;

    if not found or not l.active then
      raise exception 'Licença indisponível';
    end if;

    if l.type = 'exclusive' and b.exclusive_sold then
      raise exception 'Beat já vendido exclusivamente';
    end if;

    insert into public.acquired_licenses (
      order_item_id, buyer_id, beat_id, license_id,
      license_type, producer_id
    )
    values (
      item.id, o.buyer_id, item.beat_id, item.license_id,
      l.type, item.producer_id
    )
    on conflict (order_item_id) do nothing;

    if l.type = 'exclusive' then
      update public.beats
      set exclusive_sold = true,
          status = 'sold_exclusively',
          updated_at = now()
      where id = b.id;

      update public.licenses
      set active = false
      where beat_id = b.id
        and type = 'exclusive';

    end if;

    producer_share := item.price;

    select * into producer_wallet
    from public.wallets
    where user_id = (
      select pp.user_id
      from public.producer_profiles pp
      where pp.id = item.producer_id
    )
    and currency = item.currency
    for update;

    if not found then
      insert into public.wallets(user_id, currency, available_balance, pending_balance)
      select pp.user_id, item.currency, 0, 0
      from public.producer_profiles pp
      where pp.id = item.producer_id
      returning * into producer_wallet;
    end if;

    update public.wallets
    set pending_balance = pending_balance + producer_share
    where id = producer_wallet.id;

    insert into public.ledger_entries (
      wallet_id, entry_type, amount, currency,
      reference_type, reference_id, description
    )
    values (
      producer_wallet.id,
      'sale_pending',
      producer_share,
      item.currency,
      'order_item',
      item.id,
      'Venda de licença aguardando liberação'
    );
  end loop;
end;
$$;

-- Restringe a execução direta da função ao backend.
revoke all on function public.complete_paid_order(uuid,text,text) from public;
revoke all on function public.complete_paid_order(uuid,text,text) from anon;
revoke all on function public.complete_paid_order(uuid,text,text) from authenticated;

-- O backend com service_role pode executar a função.
grant execute on function public.complete_paid_order(uuid,text,text) to service_role;

-- Correção financeira: ledger deve ser append-only para clientes.
revoke insert, update, delete on public.ledger_entries from anon, authenticated;
