-- Beat Angola v0.7: downloads autorizados + KYC base

create table if not exists public.download_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  acquired_license_id uuid not null references public.acquired_licenses(id) on delete cascade,
  beat_file_id uuid not null references public.beat_files(id) on delete restrict,
  ip_hash text,
  user_agent text,
  created_at timestamptz not null default now()
);

create index if not exists download_events_user_idx
  on public.download_events(user_id, created_at desc);

create table if not exists public.kyc_verifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  status text not null default 'not_started'
    check (status in ('not_started','pending','verified','rejected','expired')),
  provider text,
  provider_reference text,
  country_code text,
  submitted_at timestamptz,
  verified_at timestamptz,
  expires_at timestamptz,
  rejection_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.download_events enable row level security;
alter table public.kyc_verifications enable row level security;

drop policy if exists "users read own download events" on public.download_events;
create policy "users read own download events"
on public.download_events for select
to authenticated
using (user_id = auth.uid());

drop policy if exists "users read own kyc" on public.kyc_verifications;
create policy "users read own kyc"
on public.kyc_verifications for select
to authenticated
using (user_id = auth.uid());

revoke insert, update, delete on public.download_events from anon, authenticated;
revoke insert, update, delete on public.kyc_verifications from anon, authenticated;

-- Buckets: originais e licenças devem ser privados.
-- Execute no Dashboard/SQL conforme o ambiente:
-- update storage.buckets set public = false where id in ('beat-originals','licenses');
