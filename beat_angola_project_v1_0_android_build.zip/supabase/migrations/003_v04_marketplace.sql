-- Beat Angola v0.4
-- Regras de integridade para pedidos/licenças.
-- Esta migration pressupõe as tabelas da v0.1/v0.3.

alter table public.orders
  add column if not exists paid_at timestamptz;

alter table public.order_items
  add column if not exists license_type public.license_type;

-- Preenche license_type em itens antigos quando possível.
update public.order_items oi
set license_type = l.type
from public.licenses l
where oi.license_id = l.id
  and oi.license_type is null;

-- O cliente pode criar apenas o próprio pedido.
drop policy if exists "users create own orders" on public.orders;
create policy "users create own orders"
on public.orders for insert
with check (auth.uid() = buyer_id);

-- O cliente pode inserir itens apenas num pedido seu.
drop policy if exists "users create own order items" on public.order_items;
create policy "users create own order items"
on public.order_items for insert
with check (
  exists (
    select 1 from public.orders o
    where o.id = order_items.order_id
      and o.buyer_id = auth.uid()
  )
);

-- Nunca permitir ao cliente marcar um pedido como pago.
-- Mudanças para paid/refunded/disputed devem ser feitas pelo backend
-- com service role protegido ou por uma função SQL controlada.

create or replace function public.validate_order_item_license()
returns trigger
language plpgsql
as $$
declare
  l public.licenses;
  b public.beats;
begin
  select * into l from public.licenses where id = new.license_id;
  if not found or l.beat_id <> new.beat_id or not l.active then
    raise exception 'Licença inválida ou inativa';
  end if;

  select * into b from public.beats where id = new.beat_id for update;
  if not found then
    raise exception 'Beat não encontrado';
  end if;

  if l.type = 'exclusive' and b.exclusive_sold then
    raise exception 'Este beat já foi vendido exclusivamente';
  end if;

  new.license_type := l.type;
  new.price := l.price;
  new.currency := l.currency;
  new.producer_id := b.producer_id;
  return new;
end;
$$;

drop trigger if exists trg_validate_order_item_license on public.order_items;
create trigger trg_validate_order_item_license
before insert on public.order_items
for each row execute function public.validate_order_item_license();

-- Ao confirmar uma compra exclusiva no backend, usar uma operação transacional
-- que marque beats.exclusive_sold=true e desative licenças incompatíveis.
-- Isso será implementado com o webhook de pagamento na v0.5.
