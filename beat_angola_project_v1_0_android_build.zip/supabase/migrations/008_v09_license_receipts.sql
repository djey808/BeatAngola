-- Beat Angola v0.9: documentos canónicos de licença e recibos

create table if not exists public.license_documents (
  id uuid primary key default gen_random_uuid(),
  acquired_license_id uuid not null unique
    references public.acquired_licenses(id) on delete cascade,
  document_number text not null unique,
  version integer not null default 1,
  document_hash text,
  storage_path text,
  created_at timestamptz not null default now()
);

create table if not exists public.receipts (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique
    references public.orders(id) on delete cascade,
  receipt_number text not null unique,
  currency text not null,
  amount numeric(14,2) not null,
  issued_at timestamptz not null default now(),
  storage_path text
);

alter table public.license_documents enable row level security;
alter table public.receipts enable row level security;

drop policy if exists "buyers read own license documents" on public.license_documents;
create policy "buyers read own license documents"
on public.license_documents for select
to authenticated
using (
  exists (
    select 1
    from public.acquired_licenses al
    where al.id = acquired_license_id
      and al.user_id = auth.uid()
  )
);

drop policy if exists "buyers read own receipts" on public.receipts;
create policy "buyers read own receipts"
on public.receipts for select
to authenticated
using (
  exists (
    select 1
    from public.orders o
    where o.id = order_id
      and o.user_id = auth.uid()
  )
);

revoke insert, update, delete on public.license_documents from anon, authenticated;
revoke insert, update, delete on public.receipts from anon, authenticated;

-- A função abaixo cria os documentos depois de uma ordem ser paga.
create or replace function public.create_purchase_documents(p_order_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  item record;
  receipt_currency text;
  receipt_amount numeric(14,2);
begin
  select currency, amount
    into receipt_currency, receipt_amount
  from public.orders
  where id = p_order_id
    and status = 'paid';

  if receipt_currency is null then
    raise exception 'Paid order not found';
  end if;

  insert into public.receipts(order_id, receipt_number, currency, amount)
  values (
    p_order_id,
    'BA-REC-' || upper(substr(replace(p_order_id::text, '-', ''), 1, 12)),
    receipt_currency,
    receipt_amount
  )
  on conflict (order_id) do nothing;

  for item in
    select al.id
    from public.acquired_licenses al
    where al.order_id = p_order_id
  loop
    insert into public.license_documents(
      acquired_license_id,
      document_number
    )
    values (
      item.id,
      'BA-LIC-' || upper(substr(replace(item.id::text, '-', ''), 1, 16))
    )
    on conflict (acquired_license_id) do nothing;
  end loop;
end;
$$;

revoke all on function public.create_purchase_documents(uuid) from public, anon, authenticated;
grant execute on function public.create_purchase_documents(uuid) to service_role;
