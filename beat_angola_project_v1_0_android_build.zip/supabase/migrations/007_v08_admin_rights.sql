-- Beat Angola v0.8: admin + copyright/disputes + audit

alter table public.profiles
  add column if not exists is_admin boolean not null default false;

create table if not exists public.copyright_reports (
  id uuid primary key default gen_random_uuid(),
  reporter_user_id uuid not null references auth.users(id) on delete restrict,
  beat_id uuid references public.beats(id) on delete set null,
  reason text not null,
  evidence text,
  status text not null default 'open'
    check (status in ('open','reviewing','actioned','rejected','withdrawn')),
  admin_notes text,
  resolved_by uuid references auth.users(id) on delete set null,
  resolved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.disputes (
  id uuid primary key default gen_random_uuid(),
  opened_by uuid not null references auth.users(id) on delete restrict,
  order_id uuid references public.orders(id) on delete set null,
  reason text not null,
  description text not null,
  status text not null default 'open'
    check (status in ('open','reviewing','resolved','rejected')),
  resolution text,
  resolved_by uuid references auth.users(id) on delete set null,
  resolved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id bigint generated always as identity primary key,
  actor_user_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.copyright_reports enable row level security;
alter table public.disputes enable row level security;
alter table public.audit_logs enable row level security;

-- Usuário autenticado pode criar a própria denúncia/disputa.
drop policy if exists "users create copyright reports" on public.copyright_reports;
create policy "users create copyright reports"
on public.copyright_reports for insert
to authenticated
with check (reporter_user_id = auth.uid());

drop policy if exists "users read own copyright reports" on public.copyright_reports;
create policy "users read own copyright reports"
on public.copyright_reports for select
to authenticated
using (reporter_user_id = auth.uid());

drop policy if exists "users create disputes" on public.disputes;
create policy "users create disputes"
on public.disputes for insert
to authenticated
with check (opened_by = auth.uid());

drop policy if exists "users read own disputes" on public.disputes;
create policy "users read own disputes"
on public.disputes for select
to authenticated
using (opened_by = auth.uid());

-- Auditoria só pode ser escrita pelo backend/admin.
revoke insert, update, delete on public.audit_logs from anon, authenticated;

-- Admin policies: a produção deve preferir JWT custom claims ou uma função
-- SECURITY DEFINER para evitar depender de um campo editável pelo cliente.
drop policy if exists "admins read copyright reports" on public.copyright_reports;
create policy "admins read copyright reports"
on public.copyright_reports for select
to authenticated
using (
  exists (select 1 from public.profiles p
          where p.id = auth.uid() and p.is_admin = true)
);

drop policy if exists "admins update copyright reports" on public.copyright_reports;
create policy "admins update copyright reports"
on public.copyright_reports for update
to authenticated
using (
  exists (select 1 from public.profiles p
          where p.id = auth.uid() and p.is_admin = true)
)
with check (
  exists (select 1 from public.profiles p
          where p.id = auth.uid() and p.is_admin = true)
);

drop policy if exists "admins read disputes" on public.disputes;
create policy "admins read disputes"
on public.disputes for select
to authenticated
using (
  opened_by = auth.uid()
  or exists (select 1 from public.profiles p
             where p.id = auth.uid() and p.is_admin = true)
);

drop policy if exists "admins update disputes" on public.disputes;
create policy "admins update disputes"
on public.disputes for update
to authenticated
using (
  exists (select 1 from public.profiles p
          where p.id = auth.uid() and p.is_admin = true)
)
with check (
  exists (select 1 from public.profiles p
          where p.id = auth.uid() and p.is_admin = true)
);
