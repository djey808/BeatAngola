import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config/app_config.dart';
import 'screens/auth/login_page.dart';
import 'screens/home/app_shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final url = AppConfig.supabaseUrl;
  final key = AppConfig.supabaseAnonKey;

  if (url.isNotEmpty && key.isNotEmpty) {
    await Supabase.initialize(url: url, publishableKey: key);
  }

  runApp(const BeatAngolaApp());
}

class BeatAngolaApp extends StatelessWidget {
  const BeatAngolaApp({super.key});

  @override
  Widget build(BuildContext context) {
    final configured = AppConfig.isSupabaseConfigured;

    return MaterialApp(
      title: 'Beat Angola',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorSchemeSeed: Colors.deepPurple,
      ),
      home: configured ? const AuthGate() : const ConfigPage(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    final session = Supabase.instance.client.auth.currentSession;
    return session == null ? const LoginPage() : const AppShell();
  }
}

class ConfigPage extends StatelessWidget {
  const ConfigPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.music_note, size: 64),
                const SizedBox(height: 16),
                Text('BEAT ANGOLA',
                    style: Theme.of(context).textTheme.headlineMedium),
                const SizedBox(height: 12),
                const Text(
                  'Configure SUPABASE_URL e SUPABASE_ANON_KEY para ligar esta aplicação ao backend.',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      );
}
