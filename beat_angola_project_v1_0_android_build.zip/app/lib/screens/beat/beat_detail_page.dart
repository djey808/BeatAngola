import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../models/beat.dart';
import '../../models/cart_item.dart';
import '../../services/cart_service.dart';
import '../cart/cart_page.dart';

class BeatDetailPage extends StatefulWidget {
  final Beat beat;
  const BeatDetailPage({super.key, required this.beat});

  @override
  State<BeatDetailPage> createState() => _BeatDetailPageState();
}

class _BeatDetailPageState extends State<BeatDetailPage> {
  bool loading = true;
  List<Map<String, dynamic>> licenses = [];

  @override
  void initState() {
    super.initState();
    loadLicenses();
  }

  Future<void> loadLicenses() async {
    try {
      final rows = await Supabase.instance.client
          .from('licenses')
          .select('id,name,type,price,currency,active')
          .eq('beat_id', widget.beat.id)
          .eq('active', true)
          .order('price');
      licenses = (rows as List).map((e) => Map<String, dynamic>.from(e)).toList();
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void addLicense(Map<String, dynamic> license) {
    CartService.instance.add(
      CartItem(
        beatId: widget.beat.id,
        beatTitle: widget.beat.title,
        licenseId: license['id'] as String,
        licenseName: license['name'] as String,
        licenseType: license['type'] as String,
        price: (license['price'] as num).toDouble(),
        currency: license['currency'] as String,
      ),
    );

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${license['name']} adicionada ao carrinho.'),
        action: SnackBarAction(
          label: 'Abrir',
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const CartPage()),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text(widget.beat.title),
          actions: [
            IconButton(
              icon: const Icon(Icons.shopping_cart_outlined),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CartPage()),
              ),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const AspectRatio(
              aspectRatio: 1,
              child: Card(child: Center(child: Icon(Icons.music_note, size: 90))),
            ),
            const SizedBox(height: 20),
            Text(widget.beat.title, style: Theme.of(context).textTheme.headlineMedium),
            Text(widget.beat.producerName ?? 'Produtor'),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: [
                if (widget.beat.genre != null) Chip(label: Text(widget.beat.genre!)),
                if (widget.beat.bpm != null) Chip(label: Text('${widget.beat.bpm} BPM')),
                if (widget.beat.keySignature != null) Chip(label: Text(widget.beat.keySignature!)),
              ],
            ),
            const SizedBox(height: 12),
            Text(widget.beat.description ?? 'Sem descrição.'),
            const SizedBox(height: 24),
            Text('Licenças', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 10),
            if (loading)
              const CircularProgressIndicator()
            else if (licenses.isEmpty)
              const Text('Nenhuma licença disponível.')
            else
              ...licenses.map(
                (l) => Card(
                  child: ListTile(
                    title: Text(l['name'] as String),
                    subtitle: Text((l['type'] as String) == 'exclusive'
                        ? 'Exclusiva — sujeita à disponibilidade'
                        : 'Licença conforme os termos do produtor'),
                    trailing: FilledButton(
                      onPressed: () => addLicense(l),
                      child: Text('${(l['price'] as num).toStringAsFixed(0)} ${l['currency']}'),
                    ),
                  ),
                ),
              ),
          ],
        ),
      );
}
