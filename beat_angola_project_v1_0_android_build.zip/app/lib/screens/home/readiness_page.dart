import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ReadinessPage extends StatefulWidget {
  const ReadinessPage({super.key});

  @override
  State<ReadinessPage> createState() => _ReadinessPageState();
}

class _ReadinessPageState extends State<ReadinessPage> {
  bool checking = true;
  final checks = <String, bool>{};

  @override
  void initState() {
    super.initState();
    runChecks();
  }

  Future<void> runChecks() async {
    checks['Sessão'] = Supabase.instance.client.auth.currentSession != null;
    try {
      await Supabase.instance.client.from('profiles').select('id').limit(1);
      checks['Backend Supabase'] = true;
    } catch (_) {
      checks['Backend Supabase'] = false;
    }
    try {
      await Supabase.instance.client.from('beats').select('id').eq('status', 'published').limit(1);
      checks['Marketplace'] = true;
    } catch (_) {
      checks['Marketplace'] = false;
    }
    if (mounted) setState(() => checking = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Verificação v1.0')),
    body: checking
      ? const Center(child: CircularProgressIndicator())
      : ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text('Teste rápido do ambiente', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 16),
            ...checks.entries.map((e) => Card(
              child: ListTile(
                leading: Icon(e.value ? Icons.check_circle : Icons.error),
                title: Text(e.key),
                trailing: Text(e.value ? 'OK' : 'Falhou'),
              ),
            )),
            const SizedBox(height: 16),
            const Text(
              'Pagamento real, KYC externo e payout real continuam dependentes da configuração de provedores e credenciais no backend.',
            ),
          ],
        ),
  );
}
