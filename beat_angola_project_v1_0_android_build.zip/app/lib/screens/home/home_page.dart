import 'package:flutter/material.dart';

import '../beat/beat_detail_page.dart';
import '../../models/beat.dart';
import '../explore/explore_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) => SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text('BEAT ANGOLA', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 6),
            const Text('O teu som. O teu beat. O mundo inteiro. 🌍'),
            const SizedBox(height: 24),
            TextField(
              readOnly: true,
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ExplorePage())),
              decoration: InputDecoration(
                hintText: 'Pesquisar beats, produtores, géneros...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
              ),
            ),
            const SizedBox(height: 24),
            Text('Géneros', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 10),
            const Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                Chip(label: Text('Afrobeat')),
                Chip(label: Text('Hip-Hop')),
                Chip(label: Text('Trap')),
                Chip(label: Text('R&B')),
                Chip(label: Text('Amapiano')),
                Chip(label: Text('Drill')),
              ],
            ),
            const SizedBox(height: 24),
            Text('Começa a explorar', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 10),
            Card(
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.public)),
                title: const Text('Marketplace global'),
                subtitle: const Text('Produtores de Angola e do mundo inteiro.'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ExplorePage())),
              ),
            ),
            const SizedBox(height: 12),
            ListTile(
              leading: const CircleAvatar(child: Icon(Icons.music_note)),
              title: const Text('Exemplo: Afro Vibes'),
              subtitle: const Text('Afrobeat • 102 BPM'),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const BeatDetailPage(
                    beat: Beat(id: 'demo', title: 'Afro Vibes', producerId: 'demo', producerName: 'DJ XYZ 🇦🇴', genre: 'Afrobeat', bpm: 102),
                  ),
                ),
              ),
            ),
          ],
        ),
      );
}
