import 'package:flutter/material.dart';

import '../cart/cart_page.dart';
import '../explore/explore_page.dart';
import '../library/library_page.dart';
import '../producer/publish_beat_page.dart';
import '../profile/profile_page.dart';
import 'home_page.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;

  final pages = const [
    HomePage(),
    ExplorePage(),
    PublishBeatPage(),
    LibraryPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
        body: pages[index],
        floatingActionButton: index == 1
            ? FloatingActionButton(
                tooltip: 'Carrinho',
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const CartPage()),
                ),
                child: const Icon(Icons.shopping_cart_outlined),
              )
            : null,
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (i) => setState(() => index = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Início'),
            NavigationDestination(icon: Icon(Icons.search), label: 'Explorar'),
            NavigationDestination(icon: Icon(Icons.add_box_outlined), label: 'Publicar'),
            NavigationDestination(icon: Icon(Icons.library_music_outlined), label: 'Biblioteca'),
            NavigationDestination(icon: Icon(Icons.person_outline), label: 'Perfil'),
          ],
        ),
      );
}
