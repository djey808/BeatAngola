import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../auth/login_page.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  Future<Map<String, dynamic>?> loadProfile() async {
    final id = Supabase.instance.client.auth.currentUser?.id;
    if (id == null) return null;
    return Supabase.instance.client.from('profiles').select().eq('id', id).maybeSingle();
  }

  @override
  Widget build(BuildContext context) => SafeArea(
        child: FutureBuilder<Map<String, dynamic>?>(
          future: loadProfile(),
          builder: (context, snapshot) {
            final profile = snapshot.data;
            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Text('Perfil', style: Theme.of(context).textTheme.headlineMedium),
                const SizedBox(height: 20),
                const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 42)),
                const SizedBox(height: 16),
                Text(profile?['display_name'] ?? 'Utilizador',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 8),
                Text(profile?['country_code'] ?? '--', textAlign: TextAlign.center),
                const SizedBox(height: 24),
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.badge_outlined),
                    title: const Text('Tipo de conta'),
                    subtitle: Text(profile?['role'] ?? '--'),
                  ),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () async {
                    await Supabase.instance.client.auth.signOut();
                    if (context.mounted) {
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const LoginPage()),
                        (_) => false,
                      );
                    }
                  },
                  icon: const Icon(Icons.logout),
                  label: const Text('Sair'),
                ),
              ],
            );
          },
        ),
      );
}
