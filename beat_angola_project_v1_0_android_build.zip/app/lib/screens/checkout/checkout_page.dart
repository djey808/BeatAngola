import 'package:flutter/material.dart';
import '../../services/cart_service.dart';
import '../../services/order_service.dart';
import '../../services/payment_gateway.dart';
import '../orders/order_result_page.dart';

class CheckoutPage extends StatefulWidget {
  const CheckoutPage({super.key});

  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  bool loading = false;
  String? error;

  Future<void> pay() async {
    final items = CartService.instance.items;
    if (items.isEmpty) return;

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final orderId = await OrderService().createPendingOrder(items);
      final total = items.fold<double>(0, (sum, x) => sum + x.price);
      final currency = items.first.currency;

      final session = await DemoPaymentGateway().createCheckout(
        orderId: orderId,
        amount: total,
        currency: currency,
      );

      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => OrderResultPage(
            orderId: orderId,
            checkoutId: session.checkoutId,
            providerStatus: session.status,
          ),
        ),
      );
    } catch (e) {
      if (mounted) setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final items = CartService.instance.items;
    final total = items.fold<double>(0, (sum, x) => sum + x.price);
    final currency = items.isEmpty ? 'USD' : items.first.currency;

    return Scaffold(
      appBar: AppBar(title: const Text('Checkout')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('Resumo do pedido', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 16),
          ...items.map((x) => ListTile(
                title: Text(x.beatTitle),
                subtitle: Text(x.licenseName),
                trailing: Text('${x.price.toStringAsFixed(2)} ${x.currency}'),
              )),
          const Divider(),
          ListTile(
            title: const Text('Total'),
            trailing: Text('${total.toStringAsFixed(2)} $currency',
                style: Theme.of(context).textTheme.titleLarge),
          ),
          const SizedBox(height: 20),
          const Text(
            'Na versão de produção, o botão abaixo abrirá o checkout do provedor de pagamento. '
            'A confirmação final deverá vir do backend/webhook.',
          ),
          if (error != null) ...[
            const SizedBox(height: 16),
            Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ],
          const SizedBox(height: 20),
          FilledButton(
            onPressed: loading ? null : pay,
            child: Text(loading ? 'A preparar...' : 'Continuar para pagamento'),
          ),
        ],
      ),
    );
  }
}
