import 'package:flutter/material.dart';
import '../../services/admin_service.dart';

class AdminDashboardPage extends StatefulWidget {
  const AdminDashboardPage({super.key});

  @override
  State<AdminDashboardPage> createState() => _AdminDashboardPageState();
}

class _AdminDashboardPageState extends State<AdminDashboardPage> {
  final service = AdminService();
  bool loading = true;
  List<Map<String, dynamic>> data = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      data = await service.dashboard();
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final labels = ['Utilizadores', 'Beats', 'Denúncias', 'Disputas'];
    return Scaffold(
      appBar: AppBar(title: const Text('Administração')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.25,
              ),
              itemCount: data.length,
              itemBuilder: (_, i) {
                final rows = data[i]['rows'] as List;
                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(labels[i], style: Theme.of(context).textTheme.titleMedium),
                        const Spacer(),
                        Text('${rows.length}', style: Theme.of(context).textTheme.displaySmall),
                        const Spacer(),
                        const Text('registos carregados'),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
