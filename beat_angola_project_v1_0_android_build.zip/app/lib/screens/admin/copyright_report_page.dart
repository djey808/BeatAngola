import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class CopyrightReportPage extends StatefulWidget {
  final String beatId;
  const CopyrightReportPage({super.key, required this.beatId});

  @override
  State<CopyrightReportPage> createState() => _CopyrightReportPageState();
}

class _CopyrightReportPageState extends State<CopyrightReportPage> {
  final reason = TextEditingController();
  final evidence = TextEditingController();
  bool sending = false;

  Future<void> send() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null || reason.text.trim().isEmpty) return;
    setState(() => sending = true);
    try {
      await Supabase.instance.client.from('copyright_reports').insert({
        'reporter_user_id': user.id,
        'beat_id': widget.beatId,
        'reason': reason.text.trim(),
        'evidence': evidence.text.trim(),
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Denúncia enviada para análise.')),
        );
        Navigator.pop(context);
      }
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Denunciar beat')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Descreve o motivo e apresenta evidências quando possível.'),
        const SizedBox(height: 16),
        TextField(
          controller: reason,
          maxLines: 4,
          decoration: const InputDecoration(
            labelText: 'Motivo da denúncia',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: evidence,
          maxLines: 6,
          decoration: const InputDecoration(
            labelText: 'Evidências / referências',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 20),
        FilledButton(
          onPressed: sending ? null : send,
          child: Text(sending ? 'A enviar...' : 'Enviar denúncia'),
        ),
      ],
    ),
  );
}
