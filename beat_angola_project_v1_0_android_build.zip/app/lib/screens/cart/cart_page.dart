import 'package:flutter/material.dart';
import '../../models/cart_item.dart';
import '../../services/cart_service.dart';
import '../checkout/checkout_page.dart';

class CartPage extends StatefulWidget {
  const CartPage({super.key});

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  final cart = CartService.instance;

  @override
  Widget build(BuildContext context) {
    final items = cart.items;
    final total = items.fold<double>(0, (sum, item) => sum + item.price);
    final currency = items.isEmpty ? 'USD' : items.first.currency;

    return Scaffold(
      appBar: AppBar(title: const Text('Carrinho')),
      body: items.isEmpty
          ? const Center(child: Text('O carrinho está vazio.'))
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                ...items.map(
                  (item) => Card(
                    child: ListTile(
                      title: Text(item.beatTitle),
                      subtitle: Text(item.licenseName),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text('${item.price.toStringAsFixed(2)} ${item.currency}'),
                          IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () => setState(() => cart.remove(item.beatId)),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text('Total: ${total.toStringAsFixed(2)} $currency',
                    style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const CheckoutPage()),
                  ),
                  child: const Text('Continuar para checkout'),
                ),
              ],
            ),
    );
  }
}
