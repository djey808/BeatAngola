import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class LibraryPage extends StatefulWidget {
  const LibraryPage({super.key});

  @override
  State<LibraryPage> createState() => _LibraryPageState();
}

class _LibraryPageState extends State<LibraryPage> {
  bool loading = true;
  List<dynamic> orders = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user != null) {
        orders = await Supabase.instance.client
            .from('orders')
            .select('id,amount,currency,status,created_at,order_items(beat_id,license_id,price,currency)')
            .eq('buyer_id', user.id)
            .order('created_at', ascending: false);
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text('Minha Biblioteca', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 6),
            const Text('Os teus beats e licenças comprados.'),
            const SizedBox(height: 24),
            if (loading)
              const Center(child: CircularProgressIndicator())
            else if (orders.isEmpty)
              const Card(child: ListTile(leading: Icon(Icons.library_music), title: Text('Ainda não tens compras.')))
            else
              ...orders.map((o) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.music_note),
                      title: Text('Pedido ${o['id'].toString().substring(0, 8)}'),
                      subtitle: Text('${o['amount']} ${o['currency']} • ${o['status']}'),
                    ),
                  )),
          ],
        ),
      );
}
