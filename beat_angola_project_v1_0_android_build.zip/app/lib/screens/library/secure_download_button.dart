import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../services/download_service.dart';

class SecureDownloadButton extends StatefulWidget {
  final String acquiredLicenseId;
  final String beatFileId;
  final String label;

  const SecureDownloadButton({
    super.key,
    required this.acquiredLicenseId,
    required this.beatFileId,
    this.label = 'Baixar ficheiro',
  });

  @override
  State<SecureDownloadButton> createState() => _SecureDownloadButtonState();
}

class _SecureDownloadButtonState extends State<SecureDownloadButton> {
  bool busy = false;

  Future<void> download() async {
    setState(() => busy = true);
    try {
      final url = await DownloadService().createDownloadUrl(
        acquiredLicenseId: widget.acquiredLicenseId,
        beatFileId: widget.beatFileId,
      );
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Download não autorizado: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => FilledButton.icon(
    onPressed: busy ? null : download,
    icon: const Icon(Icons.download),
    label: Text(busy ? 'A preparar...' : widget.label),
  );
}
