import 'package:flutter/material.dart';
import '../../services/purchase_documents_service.dart';

class PurchasedLicensePage extends StatefulWidget {
  final String acquiredLicenseId;
  const PurchasedLicensePage({super.key, required this.acquiredLicenseId});

  @override
  State<PurchasedLicensePage> createState() => _PurchasedLicensePageState();
}

class _PurchasedLicensePageState extends State<PurchasedLicensePage> {
  bool loading = true;
  Map<String, dynamic>? data;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      data = await PurchaseDocumentsService().license(widget.acquiredLicenseId);
    } catch (e) {
      error = e.toString();
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (error != null) return Scaffold(appBar: AppBar(), body: Center(child: Text(error!)));

    final license = Map<String, dynamic>.from(data!['license'] as Map);
    final beat = data!['beat'] == null ? null : Map<String, dynamic>.from(data!['beat'] as Map);
    final doc = license['license_documents'];
    final document = doc == null ? null : Map<String, dynamic>.from(doc as Map);

    return Scaffold(
      appBar: AppBar(title: const Text('Licença adquirida')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            beat?['title'] ?? 'Beat',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 20),
          _row('Número da licença', document?['document_number'] ?? '—'),
          _row('Tipo', license['license_type'] ?? '—'),
          _row('Preço', '${license['price']} ${license['currency']}'),
          _row('Compra', license['created_at'] ?? '—'),
          const SizedBox(height: 20),
          const Text(
            'Este documento identifica a licença adquirida. '
            'Os termos completos da licença devem ser apresentados na versão contratual final.',
          ),
        ],
      ),
    );
  }

  Widget _row(String a, dynamic b) => Card(
    child: ListTile(title: Text(a), subtitle: Text('$b')),
  );
}
