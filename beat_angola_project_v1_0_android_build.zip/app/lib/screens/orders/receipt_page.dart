import 'package:flutter/material.dart';
import '../../services/purchase_documents_service.dart';

class ReceiptPage extends StatefulWidget {
  final String orderId;
  const ReceiptPage({super.key, required this.orderId});

  @override
  State<ReceiptPage> createState() => _ReceiptPageState();
}

class _ReceiptPageState extends State<ReceiptPage> {
  bool loading = true;
  Map<String, dynamic>? receipt;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final data = await PurchaseDocumentsService().receipt(widget.orderId);
      receipt = Map<String, dynamic>.from(data['receipt'] as Map);
    } catch (e) {
      error = e.toString();
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (error != null) return Scaffold(appBar: AppBar(), body: Center(child: Text(error!)));

    return Scaffold(
      appBar: AppBar(title: const Text('Recibo')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Icon(Icons.receipt_long, size: 64),
          const SizedBox(height: 16),
          _row('Recibo', receipt!['receipt_number']),
          _row('Valor', '${receipt!['amount']} ${receipt!['currency']}'),
          _row('Emitido em', receipt!['issued_at']),
          const SizedBox(height: 20),
          const Text(
            'Este recibo comprova a transação registada pelo Beat Angola. '
            'O documento fiscal final dependerá da jurisdição e configuração da plataforma.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _row(String a, dynamic b) => Card(
    child: ListTile(title: Text(a), subtitle: Text('$b')),
  );
}
