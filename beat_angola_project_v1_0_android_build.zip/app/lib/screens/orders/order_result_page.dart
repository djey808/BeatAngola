import 'package:flutter/material.dart';
import '../../services/cart_service.dart';

class OrderResultPage extends StatelessWidget {
  final String orderId;
  final String checkoutId;
  final String providerStatus;

  const OrderResultPage({
    super.key,
    required this.orderId,
    required this.checkoutId,
    required this.providerStatus,
  });

  @override
  Widget build(BuildContext context) {
    // O carrinho só é limpo após a criação do pedido nesta demo.
    CartService.instance.clear();

    return Scaffold(
      appBar: AppBar(title: const Text('Pedido')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.receipt_long, size: 70),
              const SizedBox(height: 16),
              Text('Pedido criado', style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 12),
              Text('ID: $orderId'),
              const SizedBox(height: 8),
              Text('Checkout: $checkoutId'),
              const SizedBox(height: 8),
              Text('Estado: $providerStatus'),
              const SizedBox(height: 20),
              const Text(
                'Isto ainda não significa que o pagamento foi concluído. '
                'A próxima etapa ligará o webhook do provedor ao estado pago.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
                child: const Text('Voltar à aplicação'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
