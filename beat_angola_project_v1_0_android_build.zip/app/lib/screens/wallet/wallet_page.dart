import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../services/wallet_service.dart';
import '../payout/payout_page.dart';

class WalletPage extends StatefulWidget {
  const WalletPage({super.key});

  @override
  State<WalletPage> createState() => _WalletPageState();
}

class _WalletPageState extends State<WalletPage> {
  bool loading = true;
  List<Map<String, dynamic>> wallets = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      wallets = await WalletService().wallets();
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Carteira')),
    body: loading
        ? const Center(child: CircularProgressIndicator())
        : ListView(
            padding: const EdgeInsets.all(20),
            children: [
              ...wallets.map((w) => Card(
                child: ListTile(
                  leading: const Icon(Icons.account_balance_wallet_outlined),
                  title: Text(w['currency'] as String),
                  subtitle: Text(
                    'Disponível: ${w['available_balance']}\nPendente: ${w['pending_balance']}',
                  ),
                  isThreeLine: true,
                  trailing: FilledButton(
                    onPressed: (w['available_balance'] as num) > 0
                        ? () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => PayoutPage(
                                walletId: w['id'] as String,
                                currency: w['currency'] as String,
                                available: (w['available_balance'] as num).toDouble(),
                              ),
                            ),
                          )
                        : null,
                    child: const Text('Levantar'),
                  ),
                ),
              )),
              if (wallets.isEmpty)
                const Card(child: ListTile(title: Text('Ainda não há saldo.'))),
              const SizedBox(height: 20),
              const Text(
                'Os métodos disponíveis dependem do país, moeda, verificação e provedor.',
                textAlign: TextAlign.center,
              ),
            ],
          ),
  );
}
