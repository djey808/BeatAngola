import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../models/beat.dart';
import '../beat/beat_detail_page.dart';

class ExplorePage extends StatefulWidget {
  const ExplorePage({super.key});

  @override
  State<ExplorePage> createState() => _ExplorePageState();
}

class _ExplorePageState extends State<ExplorePage> {
  final search = TextEditingController();
  bool loading = true;
  String? error;
  List<Beat> beats = [];

  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      var query = Supabase.instance.client
          .from('beats')
          .select('id,title,producer_id,genre,bpm,key_signature,description,cover_path,preview_path,producer_profiles(stage_name)')
          .eq('status', 'published')
          .order('created_at', ascending: false);

      final rows = await query.limit(50);
      final all = (rows as List).map((e) => Beat.fromMap(Map<String, dynamic>.from(e))).toList();
      final q = search.text.trim().toLowerCase();
      beats = q.isEmpty
          ? all
          : all.where((b) =>
              b.title.toLowerCase().contains(q) ||
              (b.genre ?? '').toLowerCase().contains(q) ||
              (b.producerName ?? '').toLowerCase().contains(q)).toList();
    } catch (e) {
      error = 'Não foi possível carregar os beats.';
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  Widget build(BuildContext context) => SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
              child: TextField(
                controller: search,
                onSubmitted: (_) => load(),
                decoration: InputDecoration(
                  hintText: 'Pesquisar...',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: IconButton(icon: const Icon(Icons.search), onPressed: load),
                ),
              ),
            ),
            Expanded(
              child: loading
                  ? const Center(child: CircularProgressIndicator())
                  : error != null
                      ? Center(child: Text(error!))
                      : beats.isEmpty
                          ? const Center(child: Text('Ainda não há beats publicados.'))
                          : ListView.builder(
                              padding: const EdgeInsets.all(12),
                              itemCount: beats.length,
                              itemBuilder: (_, i) {
                                final beat = beats[i];
                                return Card(
                                  child: ListTile(
                                    leading: const CircleAvatar(child: Icon(Icons.music_note)),
                                    title: Text(beat.title),
                                    subtitle: Text('${beat.producerName ?? 'Produtor'} • ${beat.genre ?? 'Sem género'} • ${beat.bpm ?? '-'} BPM'),
                                    trailing: const Icon(Icons.chevron_right),
                                    onTap: () => Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (_) => BeatDetailPage(beat: beat)),
                                    ),
                                  ),
                                );
                              },
                            ),
            ),
          ],
        ),
      );
}
