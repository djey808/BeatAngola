import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PublishBeatPage extends StatefulWidget {
  const PublishBeatPage({super.key});

  @override
  State<PublishBeatPage> createState() => _PublishBeatPageState();
}

class _PublishBeatPageState extends State<PublishBeatPage> {
  final title = TextEditingController();
  final genre = TextEditingController(text: 'Afrobeat');
  final bpm = TextEditingController();
  final keySignature = TextEditingController();
  final description = TextEditingController();
  PlatformFile? audio;
  PlatformFile? cover;
  bool loading = false;
  String? message;

  Future<void> pickAudio() async {
    final files = await FilePicker.pickFiles(type: FileType.audio);
    if (files.isNotEmpty) setState(() => audio = files.single);
  }

  Future<void> pickCover() async {
    final files = await FilePicker.pickFiles(type: FileType.image);
    if (files.isNotEmpty) setState(() => cover = files.single);
  }

  Future<void> publish() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;
    if (title.text.trim().isEmpty) {
      setState(() => message = 'Indica o nome do beat.');
      return;
    }

    setState(() { loading = true; message = null; });
    try {
      final profile = await Supabase.instance.client
          .from('producer_profiles')
          .select('id')
          .eq('user_id', user.id)
          .maybeSingle();

      if (profile == null) {
        throw Exception('Cria primeiro o teu perfil de produtor.');
      }

      final producerId = profile['id'] as String;
      String? previewPath;

      if (audio != null) {
        final ext = audio!.extension ?? 'mp3';
        final bytes = await audio!.readAsBytes();
        previewPath = '$producerId/${DateTime.now().millisecondsSinceEpoch}.$ext';
        await Supabase.instance.client.storage
            .from('beat-previews')
            .uploadBinary(previewPath!, bytes);
      }

      final row = await Supabase.instance.client.from('beats').insert({
        'producer_id': producerId,
        'title': title.text.trim(),
        'genre': genre.text.trim(),
        'bpm': int.tryParse(bpm.text.trim()),
        'key_signature': keySignature.text.trim().isEmpty ? null : keySignature.text.trim(),
        'description': description.text.trim(),
        'preview_path': previewPath,
        'status': 'published',
      }).select('id').single();

      await Supabase.instance.client.from('licenses').insert([
        {'beat_id': row['id'], 'name': 'Não exclusiva', 'type': 'non_exclusive', 'price': 20, 'currency': 'USD', 'terms': {}, 'active': true},
        {'beat_id': row['id'], 'name': 'Premium', 'type': 'premium', 'price': 50, 'currency': 'USD', 'terms': {}, 'active': true},
        {'beat_id': row['id'], 'name': 'Exclusiva', 'type': 'exclusive', 'price': 200, 'currency': 'USD', 'terms': {}, 'active': true},
      ]);

      if (mounted) setState(() => message = 'Beat publicado com sucesso.');
    } catch (e) {
      if (mounted) setState(() => message = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text('Publicar Beat', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 6),
            const Text('Publica o teu som para compradores de qualquer país.'),
            const SizedBox(height: 24),
            TextField(controller: title, decoration: const InputDecoration(labelText: 'Nome do beat')),
            const SizedBox(height: 12),
            TextField(controller: genre, decoration: const InputDecoration(labelText: 'Género')),
            const SizedBox(height: 12),
            TextField(controller: bpm, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'BPM')),
            const SizedBox(height: 12),
            TextField(controller: keySignature, decoration: const InputDecoration(labelText: 'Tonalidade')),
            const SizedBox(height: 12),
            TextField(controller: description, maxLines: 4, decoration: const InputDecoration(labelText: 'Descrição')),
            const SizedBox(height: 16),
            OutlinedButton.icon(onPressed: pickAudio, icon: const Icon(Icons.audio_file), label: Text(audio?.name ?? 'Selecionar áudio')),
            const SizedBox(height: 8),
            OutlinedButton.icon(onPressed: pickCover, icon: const Icon(Icons.image), label: Text(cover?.name ?? 'Selecionar capa')),
            const SizedBox(height: 20),
            FilledButton(onPressed: loading ? null : publish, child: Text(loading ? 'A publicar...' : 'Publicar beat')),
            if (message != null) ...[
              const SizedBox(height: 16),
              Text(message!, textAlign: TextAlign.center),
            ],
          ],
        ),
      );
}
