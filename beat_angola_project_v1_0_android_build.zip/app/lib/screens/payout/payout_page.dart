import 'package:flutter/material.dart';
import '../../services/payout_service.dart';

class PayoutPage extends StatefulWidget {
  final String walletId;
  final String currency;
  final double available;

  const PayoutPage({
    super.key,
    required this.walletId,
    required this.currency,
    required this.available,
  });

  @override
  State<PayoutPage> createState() => _PayoutPageState();
}

class _PayoutPageState extends State<PayoutPage> {
  final amount = TextEditingController();
  final country = TextEditingController(text: 'AO');
  String? methodId;
  bool loading = true;
  bool submitting = false;
  List<PayoutMethod> methods = [];
  String? message;

  @override
  void initState() {
    super.initState();
    loadMethods();
  }

  Future<void> loadMethods() async {
    try {
      methods = await PayoutService().available(
        countryCode: country.text,
        currency: widget.currency,
      );
      if (methods.isNotEmpty) methodId = methods.first.id;
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> submit() async {
    final value = double.tryParse(amount.text.replaceAll(',', '.'));
    if (value == null || value <= 0 || value > widget.available) {
      setState(() => message = 'Indica um valor válido dentro do saldo disponível.');
      return;
    }
    if (methodId == null) {
      setState(() => message = 'Nenhum método de payout disponível.');
      return;
    }

    setState(() { submitting = true; message = null; });
    try {
      await PayoutService().request(
        walletId: widget.walletId,
        methodId: methodId!,
        amount: value,
        currency: widget.currency,
        destination: {'country': country.text.toUpperCase()},
      );
      if (mounted) setState(() => message = 'Pedido de levantamento criado.');
    } catch (e) {
      if (mounted) setState(() => message = e.toString());
    } finally {
      if (mounted) setState(() => submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Levantamento')),
    body: ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text('Saldo disponível: ${widget.available.toStringAsFixed(2)} ${widget.currency}'),
        const SizedBox(height: 20),
        TextField(
          controller: amount,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'Valor'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: country,
          decoration: const InputDecoration(labelText: 'País do produtor'),
          onSubmitted: (_) => loadMethods(),
        ),
        const SizedBox(height: 12),
        if (loading)
          const CircularProgressIndicator()
        else if (methods.isEmpty)
          const Text('Nenhum método disponível para esta combinação de país/moeda.')
        else
          DropdownButtonFormField<String>(
            value: methodId,
            decoration: const InputDecoration(labelText: 'Método'),
            items: methods
                .map((m) => DropdownMenuItem(value: m.id, child: Text(m.name)))
                .toList(),
            onChanged: (v) => setState(() => methodId = v),
          ),
        const SizedBox(height: 20),
        FilledButton(
          onPressed: submitting ? null : submit,
          child: Text(submitting ? 'A enviar...' : 'Solicitar levantamento'),
        ),
        if (message != null) ...[
          const SizedBox(height: 16),
          Text(message!, textAlign: TextAlign.center),
        ],
      ],
    ),
  );
}
