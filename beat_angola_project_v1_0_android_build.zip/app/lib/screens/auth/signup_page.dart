import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../services/auth_service.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  final country = TextEditingController(text: 'AO');
  String role = 'both';
  bool loading = false;
  String? message;

  Future<void> createAccount() async {
    setState(() {
      loading = true;
      message = null;
    });
    try {
      final response = await AuthService().signUp(
        email: email.text,
        password: password.text,
        displayName: name.text,
        countryCode: country.text,
        role: role,
      );
      if (!mounted) return;
      setState(() {
        message = response.session == null
            ? 'Conta criada. Verifica o teu email se a confirmação estiver ativa.'
            : 'Conta criada com sucesso.';
      });
    } on AuthException catch (e) {
      setState(() => message = e.message);
    } catch (_) {
      setState(() => message = 'Não foi possível criar a conta.');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Criar conta')),
        body: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Nome / nome artístico')),
            const SizedBox(height: 12),
            TextField(controller: email, decoration: const InputDecoration(labelText: 'Email')),
            const SizedBox(height: 12),
            TextField(controller: password, obscureText: true,
                decoration: const InputDecoration(labelText: 'Palavra-passe')),
            const SizedBox(height: 12),
            TextField(controller: country, decoration: const InputDecoration(labelText: 'País (ex.: AO, BR, PT)')),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: role,
              decoration: const InputDecoration(labelText: 'Quero usar como'),
              items: const [
                DropdownMenuItem(value: 'artist', child: Text('Artista / comprador')),
                DropdownMenuItem(value: 'producer', child: Text('Produtor')),
                DropdownMenuItem(value: 'both', child: Text('Artista e produtor')),
              ],
              onChanged: (v) => setState(() => role = v ?? 'both'),
            ),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: loading ? null : createAccount,
              child: Text(loading ? 'A criar...' : 'Criar conta'),
            ),
            if (message != null) ...[
              const SizedBox(height: 16),
              Text(message!, textAlign: TextAlign.center),
            ],
          ],
        ),
      );
}
