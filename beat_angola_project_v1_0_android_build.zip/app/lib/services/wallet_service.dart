import 'package:supabase_flutter/supabase_flutter.dart';

class WalletService {
  final _db = Supabase.instance.client;

  Future<List<Map<String, dynamic>>> wallets() async {
    final user = _db.auth.currentUser;
    if (user == null) return [];

    final rows = await _db
        .from('wallets')
        .select('id,currency,available_balance,pending_balance')
        .eq('user_id', user.id)
        .order('currency');

    return (rows as List).map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<List<Map<String, dynamic>>> acquiredLicenses() async {
    final rows = await _db
        .from('acquired_licenses')
        .select('id,beat_id,license_id,license_type,acquired_at')
        .order('acquired_at', ascending: false);

    return (rows as List).map((e) => Map<String, dynamic>.from(e)).toList();
  }
}
