import 'package:supabase_flutter/supabase_flutter.dart';

class PurchaseDocumentsService {
  final _db = Supabase.instance.client;

  Future<Map<String, dynamic>> license(String acquiredLicenseId) async {
    final response = await _db.functions.invoke(
      'create-license-document',
      body: {'acquired_license_id': acquiredLicenseId},
    );

    final data = Map<String, dynamic>.from(response.data as Map);
    if (data['error'] != null) throw Exception(data['error']);
    return data;
  }

  Future<Map<String, dynamic>> receipt(String orderId) async {
    final response = await _db.functions.invoke(
      'create-receipt',
      body: {'order_id': orderId},
    );

    final data = Map<String, dynamic>.from(response.data as Map);
    if (data['error'] != null) throw Exception(data['error']);
    return data;
  }

  Future<List<Map<String, dynamic>>> acquiredLicenses() async {
    final rows = await _db
        .from('acquired_licenses')
        .select('id,order_id,beat_id,license_type,price,currency,created_at')
        .order('created_at', ascending: false);

    return (rows as List)
        .map((e) => Map<String, dynamic>.from(e))
        .toList();
  }
}
