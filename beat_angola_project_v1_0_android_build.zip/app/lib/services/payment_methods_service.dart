import 'package:supabase_flutter/supabase_flutter.dart';

class PaymentMethod {
  final String id;
  final String name;
  final String provider;
  final String type;
  final String currency;

  const PaymentMethod({
    required this.id,
    required this.name,
    required this.provider,
    required this.type,
    required this.currency,
  });

  factory PaymentMethod.fromMap(Map<String, dynamic> m) => PaymentMethod(
    id: m['id'] as String,
    name: m['name'] as String,
    provider: m['provider'] as String,
    type: m['method_type'] as String,
    currency: m['currency'] as String,
  );
}

class PaymentMethodsService {
  Future<List<PaymentMethod>> available({
    required String countryCode,
    required String currency,
  }) async {
    final rows = await Supabase.instance.client
        .from('payment_methods')
        .select('id,name,provider,method_type,currency')
        .eq('enabled', true)
        .eq('currency', currency)
        .contains('countries', [countryCode.toUpperCase()]);

    return (rows as List)
        .map((e) => PaymentMethod.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }
}
