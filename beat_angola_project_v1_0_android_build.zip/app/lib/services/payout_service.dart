import 'package:supabase_flutter/supabase_flutter.dart';

class PayoutMethod {
  final String id;
  final String name;
  final String provider;
  final String methodType;
  final String currency;

  const PayoutMethod({
    required this.id,
    required this.name,
    required this.provider,
    required this.methodType,
    required this.currency,
  });

  factory PayoutMethod.fromMap(Map<String, dynamic> m) => PayoutMethod(
    id: m['id'] as String,
    name: m['name'] as String,
    provider: m['provider'] as String,
    methodType: m['method_type'] as String,
    currency: m['currency'] as String,
  );
}

class PayoutService {
  final _db = Supabase.instance.client;

  Future<List<PayoutMethod>> available({
    required String countryCode,
    required String currency,
  }) async {
    final rows = await _db
        .from('payout_methods')
        .select('id,name,provider,method_type,currency')
        .eq('enabled', true)
        .eq('currency', currency)
        .contains('countries', [countryCode.toUpperCase()]);

    return (rows as List)
        .map((e) => PayoutMethod.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<void> request({
    required String walletId,
    required String methodId,
    required double amount,
    required String currency,
    required Map<String, dynamic> destination,
  }) async {
    await _db.from('payouts').insert({
      'producer_id': null,
      'amount': amount,
      'currency': currency,
      'method': methodId,
      'provider': null,
      'status': 'requested',
      'destination': destination,
    });
  }
}
