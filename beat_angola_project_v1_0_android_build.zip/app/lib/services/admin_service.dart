import 'package:supabase_flutter/supabase_flutter.dart';

class AdminService {
  final _db = Supabase.instance.client;

  Future<List<Map<String, dynamic>>> dashboard() async {
    final results = await Future.wait([
      _db.from('profiles').select('id,display_name,country,created_at').limit(50),
      _db.from('beats').select('id,title,status,created_at').order('created_at', ascending: false).limit(50),
      _db.from('copyright_reports').select('id,beat_id,status,created_at').order('created_at', ascending: false).limit(50),
      _db.from('disputes').select('id,order_id,status,created_at').order('created_at', ascending: false).limit(50),
    ]);

    return results.map((r) => Map<String, dynamic>.from({'rows': r})).toList();
  }

  Future<void> updateReport(String id, String status, String notes) async {
    await _db.from('copyright_reports').update({
      'status': status,
      'admin_notes': notes,
      'resolved_by': _db.auth.currentUser!.id,
      'resolved_at': DateTime.now().toIso8601String(),
    }).eq('id', id);
  }

  Future<void> updateDispute(String id, String status, String resolution) async {
    await _db.from('disputes').update({
      'status': status,
      'resolution': resolution,
      'resolved_by': _db.auth.currentUser!.id,
      'resolved_at': DateTime.now().toIso8601String(),
    }).eq('id', id);
  }
}
