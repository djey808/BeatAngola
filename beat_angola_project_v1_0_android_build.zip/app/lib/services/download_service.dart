import 'package:supabase_flutter/supabase_flutter.dart';

class DownloadService {
  final _client = Supabase.instance.client;

  Future<String> createDownloadUrl({
    required String acquiredLicenseId,
    required String beatFileId,
  }) async {
    final response = await _client.functions.invoke(
      'create-download-url',
      body: {
        'acquired_license_id': acquiredLicenseId,
        'beat_file_id': beatFileId,
      },
    );

    final data = Map<String, dynamic>.from(response.data as Map);
    if (data['error'] != null) {
      throw Exception(data['error']);
    }
    return data['url'] as String;
  }

  Future<Map<String, dynamic>> licenseData(String acquiredLicenseId) async {
    final response = await _client.functions.invoke(
      'generate-license',
      body: {'acquired_license_id': acquiredLicenseId},
    );
    final data = Map<String, dynamic>.from(response.data as Map);
    if (data['error'] != null) throw Exception(data['error']);
    return Map<String, dynamic>.from(data['license'] as Map);
  }
}
