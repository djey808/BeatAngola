import '../models/cart_item.dart';

class CartService {
  CartService._();
  static final instance = CartService._();

  final List<CartItem> _items = [];

  List<CartItem> get items => List.unmodifiable(_items);

  void add(CartItem item) {
    _items.removeWhere((x) => x.beatId == item.beatId);
    _items.add(item);
  }

  void remove(String beatId) {
    _items.removeWhere((x) => x.beatId == beatId);
  }

  void clear() => _items.clear();

  double totalFor(String currency) => _items
      .where((x) => x.currency == currency)
      .fold(0, (sum, x) => sum + x.price);
}
