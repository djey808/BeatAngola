class PaymentSession {
  final String checkoutId;
  final String provider;
  final String status;

  const PaymentSession({
    required this.checkoutId,
    required this.provider,
    required this.status,
  });
}

/// Interface para o backend de pagamentos.
/// Não contém chaves secretas nem confirma pagamentos por conta própria.
abstract class PaymentGateway {
  Future<PaymentSession> createCheckout({
    required String orderId,
    required double amount,
    required String currency,
  });
}

/// Adaptador temporário para desenvolvimento.
/// Em produção, será substituído por um backend/provedor real.
class DemoPaymentGateway implements PaymentGateway {
  @override
  Future<PaymentSession> createCheckout({
    required String orderId,
    required double amount,
    required String currency,
  }) async {
    await Future<void>.delayed(const Duration(milliseconds: 500));
    return PaymentSession(
      checkoutId: 'demo_$orderId',
      provider: 'demo',
      status: 'requires_provider_confirmation',
    );
  }
}
