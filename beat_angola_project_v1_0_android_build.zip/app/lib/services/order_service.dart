import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/cart_item.dart';

class OrderService {
  final _db = Supabase.instance.client;

  Future<String> createPendingOrder(List<CartItem> items) async {
    final user = _db.auth.currentUser;
    if (user == null) throw Exception('Sessão expirada.');

    if (items.isEmpty) throw Exception('O carrinho está vazio.');

    final currency = items.first.currency;
    if (items.any((x) => x.currency != currency)) {
      throw Exception('O carrinho deve usar uma única moeda por pedido.');
    }

    final amount = items.fold<double>(0, (sum, x) => sum + x.price);

    // O cliente apenas solicita o pedido. O backend deve validar preços,
    // disponibilidade e exclusividade novamente antes de cobrar.
    final order = await _db.from('orders').insert({
      'buyer_id': user.id,
      'amount': amount,
      'currency': currency,
      'status': 'pending',
      'payment_provider': null,
    }).select('id').single();

    final orderId = order['id'] as String;

    await _db.from('order_items').insert(
      items
          .map((x) => {
                'order_id': orderId,
                'beat_id': x.beatId,
                'license_id': x.licenseId,
                'producer_id': null,
                'price': x.price,
                'currency': x.currency,
              })
          .toList(),
    );

    return orderId;
  }
}
