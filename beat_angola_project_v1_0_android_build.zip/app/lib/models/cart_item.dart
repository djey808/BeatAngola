class CartItem {
  final String beatId;
  final String beatTitle;
  final String licenseId;
  final String licenseName;
  final String licenseType;
  final double price;
  final String currency;

  const CartItem({
    required this.beatId,
    required this.beatTitle,
    required this.licenseId,
    required this.licenseName,
    required this.licenseType,
    required this.price,
    required this.currency,
  });
}
