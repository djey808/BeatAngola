class Beat {
  final String id;
  final String title;
  final String producerId;
  final String? producerName;
  final String? genre;
  final int? bpm;
  final String? keySignature;
  final String? description;
  final String? coverPath;
  final String? previewPath;

  const Beat({
    required this.id,
    required this.title,
    required this.producerId,
    this.producerName,
    this.genre,
    this.bpm,
    this.keySignature,
    this.description,
    this.coverPath,
    this.previewPath,
  });

  factory Beat.fromMap(Map<String, dynamic> map) {
    final producer = map['producer_profiles'];
    return Beat(
      id: map['id'] as String,
      title: map['title'] as String,
      producerId: map['producer_id'] as String,
      producerName: producer is Map ? producer['stage_name'] as String? : null,
      genre: map['genre'] as String?,
      bpm: map['bpm'] as int?,
      keySignature: map['key_signature'] as String?,
      description: map['description'] as String?,
      coverPath: map['cover_path'] as String?,
      previewPath: map['preview_path'] as String?,
    );
  }
}
