# Pagamentos v0.6

A documentação oficial consultada em setembro de 2026 indica que a Stripe Payments não lista Angola entre os países/regiões suportados para empresas. citeturn0search0

A documentação de PayPal indica limitações para Angola; a tabela de seller onboarding marca Angola como "Send only" para a integração de checkout. citeturn0search5

Por isso, o Beat Angola não deve assumir que um único provedor atende compradores e produtores em todos os países.

## Estratégia
1. Aceitar vários processadores.
2. Separar payment rail de payout rail.
3. Guardar o país do produtor.
4. Mostrar somente métodos compatíveis.
5. Manter ledger interno independente do provedor.
6. Permitir adicionar/remover provedores sem alterar pedidos históricos.

A documentação atual da Stripe também mostra rails de money management para Angola, mas isso não equivale a Stripe Payments estar disponível para uma empresa angolana. citeturn0search14
