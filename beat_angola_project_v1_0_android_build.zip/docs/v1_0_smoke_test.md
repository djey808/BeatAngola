# Smoke test Android — v1.0

1. Criar projeto Supabase.
2. Aplicar migrations 001–008 em ordem.
3. Criar buckets esperados:
   - beat-previews
   - beat-originals (privado)
   - beat-covers
   - licenses (privado, quando usado)
4. Configurar URL e publishable key.
5. `flutter pub get`
6. `flutter run` em Android.
7. Criar conta.
8. Criar perfil de produtor.
9. Publicar beat de teste.
10. Verificar o beat no Explorar.
11. Selecionar licença.
12. Criar pedido.
13. Confirmar que pagamento demo não é tratado como pagamento real.
14. Testar licença adquirida apenas após confirmação backend.
15. Testar download protegido.
16. Criar denúncia de copyright.
17. Testar acesso administrativo.

Não colocar service-role/secret keys no aplicativo.
