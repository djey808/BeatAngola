# v0.9 — Licença e recibo

## Licença
Cada aquisição deve permitir identificar:
- número/ID da licença;
- comprador;
- produtor;
- beat;
- tipo de licença;
- preço;
- moeda;
- data da compra;
- pedido associado.

## Recibo
O recibo é um comprovativo da transação, não substitui a licença.

## Exclusividade
A compra exclusiva é histórica e deve continuar comprovável mesmo quando o beat passa para `sold_exclusively`.

## Segurança
O cliente não pode editar uma licença adquirida. Os dados do documento são obtidos pelo backend através do utilizador autenticado e do `acquired_license_id`.
