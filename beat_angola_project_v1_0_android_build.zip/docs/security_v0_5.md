# Segurança financeira

- O Flutter não possui service role.
- O Flutter não marca pedidos como pagos.
- Webhooks precisam validar a assinatura do provedor.
- Eventos externos usam um identificador único para idempotência.
- A conclusão do pedido ocorre numa transação SQL.
- A compra exclusiva bloqueia novas compras exclusivas do mesmo beat.
- O ledger não deve ser editado pelo cliente.
- Arquivos originais devem ficar privados.
- URLs de download devem ser temporárias e emitidas somente para compradores autorizados.
