# v0.7 — Downloads e licenças

Supabase recomenda buckets privados para ficheiros que precisam de controlo de acesso; downloads podem usar RLS ou URLs assinadas com validade limitada. citeturn0search0turn0search3

A regra do Beat Angola é:

1. utilizador autenticado;
2. pedido/ordem confirmada como paga;
3. licença adquirida correspondente ao ficheiro;
4. ficheiro original pertence ao beat adquirido;
5. criar registo de download;
6. gerar URL assinada curta;
7. devolver apenas a URL temporária.

A service-role key permanece somente no backend, pois ela ignora RLS e nunca deve ser exposta no frontend. citeturn0search13

Também seguimos RLS e grants mínimos nas tabelas expostas. citeturn0search1
