# v0.8 — Administração e direitos

O painel administra:
- utilizadores e produtores;
- beats publicados/removidos;
- denúncias de copyright;
- disputas;
- licenças;
- pedidos de remoção;
- auditoria.

## Copyright
O Beat Angola não decide automaticamente a titularidade de uma obra. O sistema recolhe evidências, preserva histórico e permite decisão administrativa.

## Auditoria
Ações administrativas importantes devem gerar `audit_logs`, evitando alterações silenciosas.

## Produção
Antes de abrir o marketplace publicamente, adicionar:
- autenticação forte para admins;
- MFA;
- políticas de retenção;
- revisão jurídica por jurisdição;
- processo de contestação/contranotificação;
- proteção contra abuso de denúncias.
