# Beat Angola — v1.0

Primeira versão integrada para testes.

## Stack
- Flutter/Dart
- Supabase Auth/Postgres/Storage/Edge Functions
- RLS
- Marketplace + carrinho + checkout
- Licenças não exclusiva/premium/exclusiva
- Wallet/ledger
- Downloads protegidos
- Licença e recibo
- Copyright/disputas/admin
- Payment/payout adapters

## Dependências verificadas em 25/09/2026
- supabase_flutter 2.17.2
- file_picker 13.1.0
- just_audio 0.10.6
- url_launcher 6.3.2

As versões foram conferidas nas páginas oficiais dos pacotes no pub.dev. 
A v1.0 não contém chaves secretas nem credenciais de pagamento.

## Configuração
flutter pub get

flutter run   --dart-define=SUPABASE_URL=https://SEU-PROJETO.supabase.co   --dart-define=SUPABASE_ANON_KEY=SUA_PUBLISHABLE_KEY

Aplicar migrations na ordem 001 → 008 no projeto Supabase.

## Antes de produção
1. Recalcular preço e total exclusivamente no backend.
2. Integrar provider de pagamento compatível com cada país.
3. Validar assinatura dos webhooks.
4. Configurar payout provider.
5. KYC real.
6. MFA para administradores.
7. Revisão jurídica/fiscal por jurisdição.
8. Testes de carga, segurança e recuperação de pagamentos.
